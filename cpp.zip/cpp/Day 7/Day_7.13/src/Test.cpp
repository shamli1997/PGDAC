#include<iostream>
using namespace std;

int num1 = 10;
static int num2 = 20;

 void print( void )
{
	cout<<"Num1	:	"<<num1<<endl;
	cout<<"Num2	:	"<<num2<<endl;
}
