#include"../include/Matrix.h"
int main( void )
{
	Matrix m1(2,3);
	m1.acceptRecord( );
	m1.printRecord( );
	return 0;
}
