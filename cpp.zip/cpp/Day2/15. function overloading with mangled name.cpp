#include <iostream>
using namespace std;
void sum(int)
{
}
void sum(int, int)
{
}
void sum(int, int ,int)
{
}
int main()
{

	return 0;
}
// to compile --- > g++ Demo9.cpp --->> a.out
// to check mangled name -->> nm a.out

