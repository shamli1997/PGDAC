#include<stdio.h>
/*
int main(void)
{
	// case 1 variable is not constant  and 
    //  value of pointer and address is not constanst
	float pi=3.142f;
	float pj=10.5f;
	float *ptr=&pi;


	printf("\n *ptr=%.2f", *ptr);
	printf("\n pi=%.2f", pi);

	pi=3.15f; // allowed
	printf("\n *ptr=%.2f", *ptr);
	printf("\n pi=%.2f", pi);

	ptr=&pj; //allowed
	printf("\n *ptr=%.2f", *ptr);
	printf("\n pi=%.2f", pi);
	printf("\n pj=%.2f", pj);



	return 0;
}
*/
/*
int main(void)
{
	// case 2 variable is const and 
	// value of pointer value and address of pointer is not constant

	const float pi=3.142f;
	float pj=10.5f;

	float *ptr=&pi;

	 //pi=3.15; error as pi is const
	//pi++;
	//++pi;
	//--pi;
	//pi--;
	//pi+=10;
	//pi-=10;
	//pi*=10;
	//pi/=10;

	printf("\n *ptr=%.2f", *ptr);
	printf("\n pi=%.2f", pi);
	*ptr= 3.15; // allowed  modify the value of const variable using pointer
   // allowed as vlaue of pointer is not constant

	printf("\n *ptr=%.2f", *ptr);
	printf("\n pi=%.2f", pi);
	printf("\n pj=%.2f", pj);

	ptr=&pj; // allowed to change address of pointer as pointer is not constanst
	printf("\n *ptr=%.2f", *ptr);
	printf("\n pi=%.2f", pi);
	printf("\n pj=%.2f", pj);




	return 0;
}
*/

/*
int main(void)
{
	// case 3 variable is const and  value of pointer is const and 
    // address  of pointer is not constant


	const float pi=3.142f;
	float pj=10.5f;
	//const float *ptr=&pi; //way1 value of pointer is const
	float const  *ptr=&pi; // way2 value of pointer is const

	//pi=3.15; //error as pi is const
	//pi++;
	//++pi;
	//--pi;
	//pi--;
	//pi+=10;
	//pi-=10;
	//pi*=10;
	//pi/=10;

	printf("\n *ptr=%.2f", *ptr);
	printf("\n pi=%.2f", pi);
	//*ptr= 3.15; // not allowed to modify value of variable using pointer 
    //as value pointer is constant

	printf("\n *ptr=%.2f", *ptr);
	printf("\n pi=%.2f", pi);


	ptr=&pj; // allowed to change address of pointer  as address of pointer is not constanst
	printf("\n *ptr=%.2f", *ptr);
	printf("\n pi=%.2f", pi);
	printf("\n pj=%.2f", pj);

	return 0;
}
*/
/*
int main(void)
{
	// case 4 variable is const and  value of pointer is not const and 
    // address  of pointer is  constant

	const float pi=3.142f;
	float pj=10.5f;
	float * const ptr=&pi; //address of pointer is constant
	ptr=&pi;

	//pi=3.15; //error as pi is const
	//pi++;
	//++pi;
	//--pi;
	//pi--;
	//pi+=10;
	//pi-=10;
	//pi*=10;
	//pi/=10;

	printf("\n *ptr=%.2f", *ptr);
	printf("\n pi=%.2f", pi);
	*ptr= 3.15; // allowed to modify as value of variable using  pointer  as 
    // value of pointer is not constant

	printf("\n *ptr=%.2f", *ptr);
	printf("\n pi=%.2f", pi);


	//ptr=&pj; //not allowed to change address of pointer as pointer is  constant
	printf("\n *ptr=%.2f", *ptr);
	printf("\n pi=%.2f", pi);
	printf("\n pj=%.2f", pj);

	return 0;
}

*/


int main(void)
{
	// case 5 variable is const and  value of pointer is const and address of pointer is  constant
	const float pi=3.142f;
	float pj=10.5f;

	const float * const ptr=&pi; //address of pointer is constant and value of pointer is constant
	//float const * const ptr=&pi;

	//pi=3.15; //error as pi is const
	//pi++;
	//++pi;
	//--pi;
	//pi--;
	//pi+=10;
	//pi-=10;
	//pi*=10;
	//pi/=10;

	printf("\n *ptr=%.2f", *ptr);
	printf("\n pi=%.2f", pi);
	//*ptr= 3.15; //not  allowed  to modify value of variable as value pointer is constanst
	printf("\n *ptr=%.2f", *ptr);
	printf("\n pi=%.2f", pi);


//	ptr=&pj; //not allowed to change address as pointer as pointer is constanst
	printf("\n *ptr=%.2f", *ptr);
	printf("\n pi=%.2f", pi);
	printf("\n pj=%.2f", pj);

	return 0;
}

