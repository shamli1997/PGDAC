#include<stdio.h>
int main(void)
{
	const int arr[]={11,22,33};
	int *ptr=&arr[1];
	//arr[1]=100; //arr is const
	printf("\n arr[1]=%d *ptr=%d", arr[1], *ptr); // 22 22
	*ptr=100;
	printf("\n arr[1]=%d *ptr=%d", arr[1], *ptr);// 100 100
	printf("\n==================================\n");
	{
		const int arr[]={11,22,33};
		const int *ptr=&arr[1];
		//arr[1]=100; //arr is const
		printf("\n arr[1]=%d *ptr=%d", arr[1], *ptr); // 22 22
		//*ptr=100; as value of pointer is const
		printf("\n arr[1]=%d *ptr=%d", arr[1], *ptr);// 100 100
		ptr=&arr[2];
		printf("\n arr[2]=%d *ptr=%d", arr[2], *ptr);// 33 33
	}

	printf("\n==================================\n");
		{
			const int arr[]={11,22,33};
			const int * const ptr=&arr[1];
			//arr[1]=100; //arr is const
			printf("\n arr[1]=%d *ptr=%d", arr[1], *ptr); // 22 22
			//*ptr=100; as value of pointer is const
			printf("\n arr[1]=%d *ptr=%d", arr[1], *ptr);// 100 100
			//ptr=&arr[2]; as address of pointer is const
			printf("\n arr[2]=%d *ptr=%d", arr[2], *ptr);// 33 33
		}

	return 0;
}
