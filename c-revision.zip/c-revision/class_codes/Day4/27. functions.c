#include<stdio.h>
#include<string.h>
#define LEN 40
int MenuOperations();
size_t mystrlen(const char *s);

int main(void)
{
	char src[LEN], dest[LEN], find, *ptr=NULL;
	int choice, ans1;
	size_t ans; // unsigned int


	do
	{
		choice=MenuOperations();
		if(choice>=1 && choice<=2)
		{
			printf("\n Enter src :: ");
			//scanf("%*c"); // ignore char
			getchar();
			gets(src);
		}
		else if(choice>=3 && choice<=7)
		{
			printf("\n Enter src :: ");
			scanf("%*c");
			gets(src);
			printf("\n Enter dest :: ");
			gets(dest);
		}
		switch(choice)
		{
			case 1: // string length
					ans= mystrlen(src);
					printf("\n length of %s is %u", src, ans);
					break;
			case 2:// char search in a string
					printf("\n Enter char :: ");
					scanf("%c", &find);
					ptr= strchr(src, find);
					if(ptr==NULL)
						printf("\n %c is not found in %s", find, src);
					else
						printf("\n %c is found in %s at %d location", find, src, ptr-src);
					break;
			case 3:// string copy

					ptr= strcpy(dest, src);
					printf("\n ptr using pointer= %s", ptr);
					printf("\n  using dest =%s", dest);
					break;

					break;
			case 4:// string concate
					ptr= strcat(dest, src);
					printf("\n ptr using pointer= %s", ptr);
					printf("\n  using dest =%s", dest);
					break;

					break;
			case 5: // string compare
					ans1= strcmp(src, dest);
					if(ans1==0)
						printf("%s is equal to %s", src, dest);
					else if(ans1>0)
						printf("%s is bigger than to %s", src, dest);
					else if(ans1<0)
						printf("%s is smaller than to %s", src, dest);

					break;
			case 6: // string compare by ignoring cases
					ans1= strcasecmp(src, dest);
					if(ans1==0)
						printf("%s is equal to %s", src, dest);
					else if(ans1>0)
						printf("%s is bigger than to %s", src, dest);
					else if(ans1<0)
						printf("%s is smaller than to %s", src, dest);

					break;
			case 7: // search substring in string
					ptr= strstr(src, dest);
					if(ptr==NULL)
						printf("\n %s is not found in %s", dest, src);
					else
						printf("\n %s is found in %s at %d location", dest, src, ptr-src);

					break;
		}
	}while(choice!=0);

	return 0;
}
size_t mystrlen(const char *s)
{
	size_t i;

	/*i=0;
	while(*(s+i)!='\0') // while(s[i]!='\0')
	{
		i++;
	}
	return i;*/

	//for(i=0; *(s+i)!='\0'; i++);
	for(i=0; s[i]!='\0'; i++)
	{

	}

	return i;
}
int MenuOperations()
{
	int choice;
	printf("\n 1. strlen \n 2. strchr \n 3. strcpy \n 4. strcat");
	printf("\n 5. strcmp \n 6. strcasecmp \n 7. strstr \n 0. Exit ");

	printf("\n Enter Your choice:: ");
	scanf("%d", &choice);

	return choice;
}
// return 'A'; // return char
// return "ABC"; // return char*

