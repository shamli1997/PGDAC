#include<stdio.h>
#include<stdlib.h>
int main(void)
{
	int *ptr=NULL;
	ptr= (int *)malloc(sizeof(int)*1);
	if(ptr==NULL)
		printf("\n unable to allocate memory");
	else
	{
		*ptr=55;
		printf("\n *ptr=%d", *ptr);
		*ptr=77;
		printf("\n *ptr=%d", *ptr);
		free(ptr);
		ptr=NULL;
		//printf("\n *ptr=%d", *ptr); //error
	}
	return 0;
}

