#include<stdio.h>
#define SIZE 7
int main(void)
{
	//int arr[ 5 ];
	int arr[ SIZE ]={11, 22} , index;
	//int arr[]={11,22,33,44, 55}, index;
	printf("\n Enter elements of array :: \n");
	for(index=0; index<SIZE ; ++index)
	{
		printf("\n arr[%d]::", index);
		//scanf("%d", &arr[index]);
		scanf("%d", &index[arr]);
		//scanf("%d", (arr+index));
		//scanf("%d", (index+arr));
	}
	printf("\n Elements of array:: \n");
	for(index=0; index<SIZE; index++)
	{
		//printf("\narr[%d] %d [%u]",index, arr[index], &arr[index]);
		  printf("\narr[%d] %d [%u]",index, index[arr], &index[arr]);
		//printf("\narr[%d] %d [%u]",index, *(arr+index), (arr+index));
		//printf("\narr[%d] %d [%u]",index, *(index+arr), (index+arr));
	}
	printf("\n size of array in bytes =%d",sizeof(arr)); // size of data type * no elements
	printf("\n no of elements in array :: %d", SIZE);

	printf("\n &arr[0]=%u &arr=%u arr=%u", &arr[0], &arr, arr);
	printf("\n &arr[0]+1=%u &arr+1=%u arr=+1%u", &arr[0]+1, &arr+1, arr+1);
	printf("\n *arr=%d", *arr);

	//arr++; //lvalue req error
	//++arr;
	//--arr;
	//arr--;
	//5++;

	printf("\n ++arr[0]= %d", ++arr[0]); // allowed
	printf("\n --arr[0]= %d", --arr[0]);
	printf("\n arr[0]--= %d", arr[0]--);
	printf("\n arr[0]++= %d", arr[0]++);
	printf("\n\n\n\n");

	return 0;
}
