#include<stdio.h>
#define SIZE 5
//void ReadArray(int a[SIZE], int size);
void ReadArray(int a[], int size); // array notation
//void ReadArray(int *a, int size);// pointer notation
//void PrintArray(int a[], int size); // array notation
void PrintArray(int *a, int size); // pointer notation
int main(void)
{
	int arr[ SIZE ], arr1[7];

	printf("\n Enter elements of array :: \n");
	ReadArray(arr, SIZE);

	printf("\n Elements of array:: \n");
	PrintArray(arr, SIZE);

	printf("\n size of array in bytes =%d",sizeof(arr)); // size of data type * no elements
	printf("\n no of elements in array :: %d", SIZE);

	printf("\n Enter elements of array1 :: \n");
	ReadArray(arr1, 7);

	printf("\n Elements of array:: \n");
	PrintArray(arr1, 7);

	printf("\n\n\n\n");
// arr++;
	return 0;
}
void ReadArray(int a[], int size) // array notation
{
	int index;
	for(index=0; index<size ; ++index)
	{
		// using array notation
		printf("\n a[%d]::", index);
		//scanf("%d", &a[index]);
		scanf("%d", &index[a]);
		// using pointer notation
		//scanf("%d", (a+index));
		//scanf("%d", (index+a));
	}
	printf("\nsize of a=%d", sizeof(a)); // a is a pointer
	a++; // pointer ++ allowed

	return;
}
void PrintArray(int *a, int size) // pointer notation
{
	int index;
	for(index=0; index<size; index++)
	{
		// using array notation
		//printf("\narr[%d] %d [%u]",index, a[index], &a[index]);
		  printf("\narr[%d] %d [%u]",index, index[a], &index[a]);
		  // using pointer notation
		  //printf("\narr[%d] %d [%u]",index, *(a+index), (a+index));
		//printf("\narr[%d] %d [%u]",index, *(index+a), (index+a));
	}
	return;
}
