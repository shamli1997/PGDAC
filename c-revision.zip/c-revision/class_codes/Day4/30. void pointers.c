#include<stdio.h>
int main(void)
{
	void *ptr=NULL;
	int a=10;
	float f=10.2f;
	char ch='A';

	ptr=&a; // a is of int data tpye
	//printf("\n *ptr=%d", *ptr); //error as ptr is void pointer
	printf("\n *ptr=%d", *(int*)ptr);

	ptr=&f;
	//printf("\n *ptr=%d", *ptr); //error as ptr is void pointer
	printf("\n *ptr=%.2f", *(float*)ptr);

	ptr=&ch;
	//printf("\n *ptr=%d", *ptr); //error as ptr is void pointer
	printf("\n *ptr=%c", *(char*)ptr);

	ptr= &a;
	printf("\n ptr=%u", ptr);
	ptr++; // should give error std
	//will increment by 1 on gcc
	printf("\n ptr=%u", ptr);
	return 0;
}
