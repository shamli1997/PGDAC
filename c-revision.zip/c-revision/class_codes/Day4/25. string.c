#include<stdio.h>
#include<string.h>
#define LEN 40
int main(void)
{
	// string
	char city1[]="pune"; // \0 added at the end by compiler
	char city2[LEN]="karad";
	char city3[LEN]={'p','u', 'n', 'e', '\0'};
	char city4[]={'k','a', 'r', 'a','d', '\0'};

	// array of char
	char city5[]={'k','a', 'r', 'a','d'};

	printf("\n len of city1 %s = %d", city1, strlen(city1));
	printf("\n sizeof of city1%s= %d", city1, sizeof(city1));

	printf("\n len of city2 %s=%d", city2, strlen(city2));
	printf("\n sizeof of city2 %s=%d", city2, sizeof(city2));

	printf("\n len of city3 %s=%d", city3, strlen(city3));
	printf("\n sizeof of city3 %s=%d", city3, sizeof(city3));

	printf("\n len of city4 %s=%d", city4, strlen(city4));
	printf("\n sizeof of city4 %s=%d", city4, sizeof(city4));

	printf("\n enter city2 :: ");
	//scanf("%s", city2); // scan upto space
    //gets(city2); // scan upto new line char \n
    //scanf("%[^\n]s", city2); // scan upto \n char  single line
    //scanf("%[^.]s", city2); //scan upto . char
	//scanf("%[^g]s", city2); //scan upto g letter
	//scanf("%[A-Z]s",city2); // scan upto capital leters
	//scanf("%[a-z]s",city2); // scan upto small letters
	//scanf("%[0-9]s",city2); // scan upto digits
	//scanf("%[^0-9]s",city2); // scan upto letters
	//scanf("%[^A-Z]s",city2); // scan upto small letters
	scanf("%[^a-z]s",city2); // scan upto capital letters
	printf("\n city2=%s",city2 );


	return 0;
}

// return 'A'; // return char
// return "ABC"; // return char*

