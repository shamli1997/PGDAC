#include <stdio.h>
#define sq(a) a*a
#define sq1(a) (a)*(a)
int main(void)
{
	int x=5, y=0;

	y= sq(x); // y=x*x // y=5*5
	printf("\nx=%d y=%d", x, y);

	y= sq(x+x); // y=x+x*x+x // y=5+5*5+5 // y= 5+25+5 // 35
	printf("\nx=%d y=%d", x, y);

	y= 25/sq(x); // y=15/y+y // y=25/5*5 // y=5*5 //y=25
	printf("\nx=%d y=%d", x, y);

	y= sq1(x+x); // y=(x+x)*(x+x) // y=(5+5)*(5+5) // y= 10*10 // 100
	printf("\nx=%d y=%d", x, y);

	return 0;
}
