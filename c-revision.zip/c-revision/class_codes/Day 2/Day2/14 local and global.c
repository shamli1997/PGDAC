#include<stdio.h>
extern int no1; // decl of global variable
int main(void)
{
	printf("\n no1=%d &no1=%u in global", no1, &no1);
	{ // block1
		int no1=10; // decl and defination local variable
		printf("\n no1=%d &no1=%u in block 1", no1, &no1);
		{
			// block2
			int no1=100;
			printf("\n no1=%d &no1=%u in block 2", no1, &no1);
		}
		printf("\n no1=%d &no1=%u in block 1", no1, &no1);
	}
	printf("\n no1=%d &no1=%u in global", no1, &no1);
	return 0;
}
int no1=1000; // defination of global variable
