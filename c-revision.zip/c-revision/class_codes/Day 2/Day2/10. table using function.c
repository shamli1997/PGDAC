#include <stdio.h>
void table(int n);
int table_no(int n, int c);
int main(void)
{
	int no, cnt;
	printf("\n Enter no :: ");
	scanf("%d", &no);
	table(no);

	printf("\n print table in main :: \n");
	for(cnt=1; cnt<=10; cnt++)
	{
		printf("%5d * %5d  =  %5d\n", no, cnt, table_no(no, cnt));
	}

	printf("\n end of main\n");
	return 0;
}
void table(int n)
{
	int counter;
	printf("\n print table of %d in function\n", n);
	for(counter=1; counter<=10; counter++)
	{
		printf("\n %5d * %5d = %5d", n, counter, n*counter);
	}
	return ;
}
int table_no(int n, int c)
{
	return n*c;
}

