#include<stdio.h>
//static int no=1;
//int no=1;
int main(void)
{
	static int no=1;
	if(no>100)
		return 0;
	else
	{
		printf("\n%4d [%u]",no, &no);
		no++;
	}
	main(); // call main rec
	return 0;
}
