#include <stdio.h>
int factorial(int n);
int main(void)
{
	int no, ans=0;
	printf("\n Enter No :: ");
	scanf("%d", &no);
	ans= factorial(no);
	printf("\n %d!=%d", no, ans);
	return 0;
}
int factorial(int n)
{
	int i,f;
	/*for(f=i=1; i<=n; ++i)
	{
		printf("%d*", i);
		f*=i;//f=f*i;
	}*/

	/*for(f=1,i=n; i>=1; --i)
	{
		printf("%d*", i);
		f*=i;//f=f*i;
	}*/

	/*i=f=1;
	while(i<=n)
	{
		printf("%d*", i);
		f*=i; // f=f*i;
		++i;// incre
	}*/

	/*f=1;
	i=n;
	while(i>=1)
	{
		printf("%d*", i);
		f*=i; // f=f*i;
		--i;// decre
	}*/

	/*i=f=1; //init
	while(1)  // condition
	{
		printf("%d*", i);
		f*=i; // f=f*i;
		++i;// incre
		if(i>n)
			break;
	}*/
	f=i=1;
	for(;;)
	{
		printf("%d*", i);
		f*=i;//f=f*i;
		++i;
		if(i>n)
			break;
	}
	return f;
}
// return 11;  return type int
// return 11.1;  return type double
// return 11.4f;  return type float
// return 11.4F;  return type float
// return 'A';  return type char
// return ;  return type void
//return "sunbeam"; return type char*
