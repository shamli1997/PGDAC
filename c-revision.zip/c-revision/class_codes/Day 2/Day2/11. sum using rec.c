#include<stdio.h>
int sum (int no);
int main(void)
{
	int a, ans=0;
	printf("\n Enter No :-");
	scanf("%d",&a);
	ans=sum(a);
	printf("\n Sum=%d", ans);
	return 0;
}
int sum(int no)
{
	int add=0;
	printf("\n no=%d [%u] ", no, &no);
	//getchar();
    if(no==1) // termination condition
    {
    	add=1;
    	printf("\n no=%d [%u] add=%d [%u]",no, &no, add, &add );
    	return 1;
    }
    else
    {
    	//add=no+sum(no--); // recursive formula
      	//add=no+sum(--no); // recursive formula
       add=no+sum(no-1); // recursive formula
      	printf("\n no=%d [%u] add=%d [%u]",no, &no, add, &add );
    }
    return add;
}

