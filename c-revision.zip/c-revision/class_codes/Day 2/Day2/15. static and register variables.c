#include<stdio.h>
//register int no=100; error
//int no6=no2; //error 
int no7=9; //global variable
int main(void)
{
	register int no=100;
	//printf("\n no=%d &no1=%u", no, &no); //error
	printf("\n no=%d ", no);
	printf("\n Enter no :: ");
	//scanf("%d", &no); error

	int no2=100;
	//static int no2=no2; //error

	static int no4=10000;
	printf("\n no2=%d no4=%d", no2,no4);
	return 0;
}

