#include <stdio.h>
//1. fun decl or proto type fun
// output function_name(input);
//int addition(int n1, int n2); // global decl
//return type function_name(datatype parameter1);
int main(void)
{
	//int addition(int n1, int n2); // local decl
	int no1, no2, ans;
	ans=addition(no1, no2); //3. function call
	printf("\n Enter No1 :: ");
	scanf("%d", &no1);
	printf("\n Enter No2 :: ");
	scanf("%d", &no2);
	ans=0;
	ans=addition(no1, no2); //3. function call
	// no1 , no2 actual arguments
	printf("\n %d + %d  = %d",no1, no2,ans );
	return 0;
}
//2. fun defination or logic
// n1 , n2 are formal arguments
int addition(int n1, int n2)
{
	int temp=0;
	temp=n1+n2;
	return temp;
}
