#include<stdio.h>
void fun ();
//static int no=1;
int no=1;
int main(void)
{
	fun();
	return 0;
}
void fun ()
{
	//static int no=1;
	if(no>100)
		return;
	else
	{
		printf("\n%4d [%u]",no, &no);
		no++;
	}
	fun();
}
