#include <stdio.h>
//1. fun decl or proto type fun
// output function_name(input);
//float addition(float n1, float n2); // global decl
//return type function_name(datatype parameter1);

//2. fun defination or logic
// n1 , n2 are formal arguments
float addition(float n1, float n2)
{
	float temp=0;
	temp=n1+n2;
	return temp;
}
int main(void)
{
	//int addition(int n1, int n2); // local decl
	float no1, no2, ans;
	ans=addition(no1, no2); //3. function call
	printf("\n Enter No1 :: ");
	scanf("%f", &no1);
	printf("\n Enter No2 :: ");
	scanf("%f", &no2);
	ans=0;
	ans=addition(no1, no2); //3. function call
	// no1 , no2 actual arguments
	printf("\n %f + %f  = %f",no1, no2,ans );
	return 0;
}

