#include<stdio.h>
int main(void)
{
	{
		int z=3;
		//int *z_ptr=&z;
		//or
		int *z_ptr=NULL;
		z_ptr=&z;

		printf("\n int data type :: \n");
		printf("\n size of z_ptr=%d", sizeof(z_ptr));
		printf("\n z=%d *(&z)=%d *z_ptr=%d", z, *(&z), *z_ptr);
		printf("\n z=%u z_ptr=%u &z_ptr=%u", &z, z_ptr, &z_ptr);
		printf("\n z=%p z_ptr=%p &z_ptr=%p", &z, z_ptr, &z_ptr);

		*z_ptr=5;
		printf("\n z=%d *(&z)=%d *z_ptr=%d", z, *(&z), *z_ptr);
		printf("\n z=%u z_ptr=%u &z_ptr=%u", &z, z_ptr, &z_ptr);
		printf("\n z_ptr=%u z_ptr+1=%u", z_ptr, z_ptr+1);
		printf("\n z_ptr=%u z_ptr-1=%u", z_ptr, z_ptr-1);
		printf("\n z_ptr=%u z_ptr+5=%u", z_ptr, z_ptr+5);
		printf("\n z_ptr=%u z_ptr-5=%u", z_ptr, z_ptr-5);
		printf("\n z_ptr=%u z_ptr*5=%u", z_ptr, z_ptr*5);
		printf("\n z_ptr=%u z_ptr/5=%u", z_ptr, z_ptr/5);

	}
	printf("\n============================================\n");
	{
			char z='A';
			//char *z_ptr=&z;
			//or
			char *z_ptr=NULL;
			z_ptr=&z;

			printf("\n char data type :: \n");
			printf("\n size of z_ptr=%d", sizeof(z_ptr));
			printf("\n z=%c *(&z)=%c *z_ptr=%c", z, *(&z), *z_ptr);
			printf("\n z=%u z_ptr=%u &z_ptr=%u", &z, z_ptr, &z_ptr);
			printf("\n z=%p z_ptr=%p &z_ptr=%p", &z, z_ptr, &z_ptr);

			*z_ptr='B';
			printf("\n z=%c *(&z)=%c *z_ptr=%c", z, *(&z), *z_ptr);
			printf("\n z=%u z_ptr=%u &z_ptr=%u", &z, z_ptr, &z_ptr);

			printf("\n z_ptr=%u z_ptr+1=%u", z_ptr, z_ptr+1);
			printf("\n z_ptr=%u z_ptr-1=%u", z_ptr, z_ptr-1);
			printf("\n z_ptr=%u z_ptr+5=%u", z_ptr, z_ptr+5);
			printf("\n z_ptr=%u z_ptr-5=%u", z_ptr, z_ptr-5);

		}
	printf("\n============================================\n");

	printf("\n============================================\n");
	{
		float z=10.2f;
		//float *z_ptr=&z;
		//or
		float *z_ptr=NULL;
		z_ptr=&z;

		printf("\n float data type :: \n");
		printf("\n size of z_ptr=%d", sizeof(z_ptr));
		printf("\n z=%f *(&z)=%f *z_ptr=%f", z, *(&z), *z_ptr);
		printf("\n z=%u z_ptr=%u &z_ptr=%u", &z, z_ptr, &z_ptr);
		printf("\n z=%p z_ptr=%p &z_ptr=%p", &z, z_ptr, &z_ptr);

		*z_ptr=12.34f;
		printf("\n z=%f *(&z)=%f *z_ptr=%f", z, *(&z), *z_ptr);
		printf("\n z=%u z_ptr=%u &z_ptr=%u", &z, z_ptr, &z_ptr);
		printf("\n z_ptr=%u z_ptr+1=%u", z_ptr, z_ptr+1);
		printf("\n z_ptr=%u z_ptr-1=%u", z_ptr, z_ptr-1);
		printf("\n z_ptr=%u z_ptr+5=%u", z_ptr, z_ptr+5);
		printf("\n z_ptr=%u z_ptr-5=%u", z_ptr, z_ptr-5);

		}
		printf("\n============================================\n");

	return 0;
}

