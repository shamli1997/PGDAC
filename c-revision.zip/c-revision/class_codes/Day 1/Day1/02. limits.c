
#include <stdio.h>
#include <stdlib.h>
#include<limits.h>
int main(void)
{
	int no1=100;
	char ch='A';
	printf("\n int %%d %d %d to %d", sizeof(int), INT_MIN, INT_MAX);
	printf("\n no1=%d no1=%o no1=%x", no1, no1, no1);
	printf("\n no2=%d", 0100);

	printf("\n size of 10=%d", sizeof(10));
	printf("\n size of 10.10=%d", sizeof(10.10));
	printf("\n size of 10.10f=%d", sizeof(10.10f));
	printf("\n size of 10.10F=%d", sizeof(10.10F));
	printf("\n size of ch=%d", sizeof(ch));
	printf("\n size of ch=%d", sizeof('A'));

	return EXIT_SUCCESS;
}
