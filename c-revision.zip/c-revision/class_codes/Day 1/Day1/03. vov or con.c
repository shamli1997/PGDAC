
#include <stdio.h>
#include <stdlib.h>
#include<limits.h>
int main(void)
{
	/*int no1=1, no2=-1;

	if(no1, no2, no1, no2)
	{
		printf("\nyes");
		//break;
	}
	else;
	{
		printf("\nno");
	}*/

	char ch;

	printf("\n enter char ::");
	scanf("%c",&ch);

	printf("\n ch=%d ch=%c", ch, ch);

	if( ch>=97 &&ch<=122) //convert to capital letters
		ch-=32;  //ch= ch-32;

	printf("\n ch=%d ch=%c", ch, ch);

	if( ch=='A' || ch=='E' || ch=='I' || ch=='O' ||ch=='U')
		printf("\n %c is vov", ch);
	else if(ch>=65 && ch<=90)
		printf("\n %c is con", ch);
	else if(ch>=48 && ch<=57)
		printf("\n %c is digit", ch);
	else
		printf("\n %c is other", ch);

	return EXIT_SUCCESS;
}
