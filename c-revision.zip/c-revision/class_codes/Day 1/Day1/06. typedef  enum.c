#include <stdio.h>
//way1
/*typedef enum color
{
	RED, BLACK, GREEN=5,YELLOW
//   0     1     5        6
}COLOR;*/
//way2
enum color
{
	RED, BLACK, GREEN=5,YELLOW
//   0     1     5        6
};
typedef enum color COLOR;
int main(void)
{
	COLOR c;//enum color c;
	int no;
	// enum color is user define data type
	//c is variable of user define data type  enum color
	// memory will be taken by c (variable of enum color)

	printf("\n 0. Red 1. Black 5.Green 6. Yellow  ");
	printf("\n Enter your no :: ");
	//scanf("%d", &c);// way1. scan enum variable c

	scanf("%d", &no);
	//c=(enum color) no; // way2 scan int and assign to enum after tyepcast

	// way3 using switch case and c

	switch(no)
	{
		case 0:  c= RED; break;
		case 1:  c= BLACK; break;
		case 5:  c= GREEN; break;
		case 6:  c= YELLOW; break;
		default :c=100; break;
	}


	switch(c)
	{
		case RED : printf("\n Red color"); break;
		case BLACK : printf("\n black color"); break;
		case YELLOW : printf("\n Yellow color"); break;
		case GREEN : printf("\n Green color"); break;
		default : printf("\n invalid color ");

	}
	printf("\n size of enum color =%d", sizeof(c));
	printf("\n size of enum color =%d", sizeof(enum color));
	
	return 0;
}
