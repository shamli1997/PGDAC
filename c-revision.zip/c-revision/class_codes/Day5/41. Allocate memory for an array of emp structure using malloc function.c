#include<stdio.h>
#include<stdlib.h>
#pragma pack(1)
struct emp
{
	int empno;
	char name[10];
	float sal;
};
int main(void)
{
	struct emp *ptr=NULL;
	int no, i;

	printf("\n Enter How many emp you want ::");
	scanf("%d",&no);

	ptr= (struct emp*)malloc(sizeof(struct emp)*no);

	for(i=0; i<no; i++)
	{
		printf("\n Enter Emp no :: ");
		scanf("%d", &ptr[i].empno);

		printf("\n Enter Emp name:: ");
		scanf("%s", ptr[i].name);

		printf("\n Enter Emp sal:: ");
		scanf("%f", &ptr[i].sal);
	}

	printf("\n emp info :: \n");
	printf("\n EmpNo     name   sal using -> operator\n");
	for(i=0; i<no; i++)
	{
		//printf("\n %-6d %-10s %6.2f", ptr[i].empno, ptr[i].name, ptr[i].sal);
		printf("\n %-6d %-10s %6.2f", (ptr+i)->empno, (ptr+i)->name, (ptr+i)->sal);
	}


	free(ptr);
	ptr=NULL;
	printf("\n Memory is freed");
	return 0;
}


