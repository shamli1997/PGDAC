#include<stdio.h>
#include<stdlib.h>
#pragma pack(1)
struct emp
{
	int empno;
	char name[10];
	float sal;
};
void AcceptEmpInfo(struct emp e);
void PrintEmpInfo(struct emp e);
int main(void)
{
	struct emp e1;
	// struct emp is user defined data type
	// e1 is variable (object) of user defined data type struct emp

	printf("\n Enter Employee info :: ");
	AcceptEmpInfo(e1); // e1 is actual argument

	printf("\n Employee info :: in main \n"); // grabage values will print in main
 	PrintEmpInfo(e1);// e1 is actual argument

	return 0;
}
// e is formal argument
void AcceptEmpInfo(struct emp e)
{
	printf("\n Enter Emp no:: ");
	scanf("%d", &e.empno);

	printf("\n Enter Emp name:: ");
	scanf("%s", e.name);

	printf("\n Enter Emp sal:: ");
	scanf("%f", &e.sal);

	printf("\n in AcceptEmpInfo :: \n");
	PrintEmpInfo(e);
	return;
}
//e is formal argument
void PrintEmpInfo(struct emp e)
{
	printf("\n EmpNo     name   sal \n");
	printf("\n %-6d %-10s %6.2f", e.empno, e.name, e.sal);

	return;
}



