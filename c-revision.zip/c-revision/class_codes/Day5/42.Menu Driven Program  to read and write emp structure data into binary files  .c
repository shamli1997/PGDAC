#include<stdio.h>
#include<stdlib.h>
#pragma pack(1)
struct emp
{
	int empno;
	char name[10];
	float sal;
};
void AcceptEmpInfo(struct emp *e);
void WriteEmpInfoInBinaryFile();
void ReadEmpInfoFromBinaryFile();
void PrintEmpInfo(const struct emp *e);
int MenuChoice();
int main(void)
{
	int choice;
	do
	{
		choice= MenuChoice();

		switch(choice)
		{
			case 1: // write emp data in file
					WriteEmpInfoInBinaryFile();
					break;
			case 2:// read emp data from file
					ReadEmpInfoFromBinaryFile();
					break;
			default:
					printf("\n invalid choice:: ");
					continue;
		}

		printf("\n enter 1 to continue or 0 to exit  :: ");
		scanf("%d", &choice);

	}while(choice!=0);
	return 0;
}
int MenuChoice()
{
	int choice;
	printf("\n 1. Add Emp Record in file ");
	printf("\n 2. Read Emp Record from flie \n 0.Exit");
	printf("\n Enter Your choice :: ");
	scanf("%d", &choice);
	return choice;
}
void AcceptEmpInfo(struct emp *e)
{
	printf("\n Enter Emp no :: ");
	scanf("%d",&e->empno);

	printf("\n Enter Emp name :: ");
	scanf("%s",e->name);

	printf("\n Enter Emp sal :: ");
	scanf("%f",&e->sal);
	return;
}
void PrintEmpInfo(const struct emp *e)
{
	printf("\n%-6d%-10s%-6.2f", e->empno, e->name, e->sal);
	return;
}
void WriteEmpInfoInBinaryFile()
{
	struct emp e1;
	FILE *fpEmpWrite=NULL;
	//fpEmpWrite= fopen("emp.dat","ab");

	//fpEmpWrite= fopen("d:\\rahul\\DAC_Aug2019\\emp.dat","ab"); //on windows
	fpEmpWrite= fopen("/home/rahul/DAC_Aug2019/emp.dat","ab");

	if(fpEmpWrite==NULL)
		printf("\n unable to open file");
	else
	{
		printf("\n Enter emp info :: ");
		AcceptEmpInfo(&e1);
		fwrite(&e1, sizeof(struct emp), 1, fpEmpWrite);
		fclose(fpEmpWrite);
		printf("\n record is added to file");
	}
	return;
}
void ReadEmpInfoFromBinaryFile()
{
	int cnt=0;
	struct emp e1;
	FILE *fpEmpRead=NULL;
	fpEmpRead= fopen("/home/rahul/DAC_Aug2019/emp.dat", "rb");
	if(fpEmpRead==NULL)
		printf("\n unable to read file");
	else
	{
		// read 1st record from file
		/*
		printf("\n EmpNo   Name  Salary ");
		fread(&e1, sizeof(struct emp),1, fpEmpRead);
		PrintEmpInfo(&e1);*/

		printf("\n EmpNo   Name  Salary ");
		while(fread(&e1, sizeof(struct emp),1, fpEmpRead))
		{
			PrintEmpInfo(&e1);
			cnt++;
		}
		fclose(fpEmpRead);
		printf("\n%d records  read from file",cnt);
	}
	return;
}
