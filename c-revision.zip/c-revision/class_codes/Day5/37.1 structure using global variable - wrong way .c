#include<stdio.h>
#include<stdlib.h>
#pragma pack(1)
struct emp
{
	int empno;
	char name[10];
	float sal;
};
struct emp e;
void AcceptEmpInfo(struct emp e); // pass by value - copy - 
void PrintEmpInfo(struct emp e);
int main(void)
{

	printf("\n Enter Employee info :: ");
	AcceptEmpInfo(e);

	printf("\n Employee info :: in main \n");
 	PrintEmpInfo(e);

	return 0;
}

void AcceptEmpInfo(struct emp e)
{
	printf("\n Enter Emp no:: ");
	scanf("%d", &e.empno);

	printf("\n Enter Emp name:: ");
	scanf("%s", e.name);

	printf("\n Enter Emp sal:: ");
	scanf("%f", &e.sal);

	return;
}

void PrintEmpInfo(struct emp e)
{
	printf("\n EmpNo     name   sal \n");
	printf("\n %-6d %-10s %6.2f", e.empno, e.name, e.sal);
	return;
}


