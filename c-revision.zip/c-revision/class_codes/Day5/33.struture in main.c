#include<stdio.h>
#include<stdlib.h>
// to remove slack bytes
#pragma pack(1) // struct member alligment 1 byte
struct emp
{
	int empno;
	char name[10];
	float sal;
};
int main(void)
{
	//struct emp e1;
	//struct emp e1={1};
	struct emp e1={1,"rahul"};
	struct emp *ptr=&e1;
	// struct emp is user defined data type
	// e1 is variable (object) of user defined data type struct emp

	printf("\n size of e1=%d", sizeof(e1));
	printf("\n size of ptr=%d", sizeof(ptr));

	printf("\n &e1=%u &e1+1=%u",&e1,&e1+1  ); // scale factor of pointer is 18
	printf("\n ptr=%u ptr+1=%u",ptr,ptr+1  );

	printf("\n Enter Emp no:: ");
	scanf("%d", &e1.empno);

	printf("\n Enter Emp name:: ");
	scanf("%s", e1.name);

	printf("\n Enter Emp sal:: ");
	scanf("%f", &e1.sal);


	printf("\n EmpNo     name   sal \n");
	printf("\n %-6d %-10s %6.2f", e1.empno, e1.name, e1.sal);

	printf("\n EmpNo     name   sal using pointer\n");
	printf("\n %-6d %-10s %6.2f", ptr->empno, ptr->name, ptr->sal);

	printf("\n EmpNo     name   sal using pointer\n");
	printf("\n %-6d %-10s %6.2f", (*ptr).empno, (*ptr).name, (*ptr).sal);

	return 0;
}



