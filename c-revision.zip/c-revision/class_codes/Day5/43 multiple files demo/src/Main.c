#include<stdio.h>
#include"../include/EmpDemo.h"
#include"../include/EmpDemo.h"

int main(void)
{
	int choice;
	do
	{
		choice= MenuChoice();

		switch(choice)
		{
			case 1: // write emp data in file
					WriteEmpInfoInBinaryFile();
					break;
			case 2:// read emp data from file
					ReadEmpInfoFromBinaryFile();
					break;
			default:
					printf("\n invalid choice:: ");
					continue;
		}

		printf("\n enter 1 to continue or 0 to exit  :: ");
		scanf("%d", &choice);

	}while(choice!=0);

	printf("\n file name =%s", __FILE__);
	printf("\n date =%s", __DATE__);
	printf("\n time =%s", __TIME__);
	printf("\n line no =%d", __LINE__);
	#line 0
	printf("\n line no =%d", __LINE__);
	return 0;
}





