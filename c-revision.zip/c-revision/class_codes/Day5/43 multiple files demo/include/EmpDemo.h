#ifndef EMPDEMO_H_
#define EMPDEMO_H_


#pragma pack(1)
struct emp
{
	int empno;
	char name[10];
	float sal;
};
void AcceptEmpInfo(struct emp *e);
void WriteEmpInfoInBinaryFile();
void ReadEmpInfoFromBinaryFile();
void PrintEmpInfo(const struct emp *e);
int MenuChoice();

#endif /* EMPDEMO_H_ */
