#include<stdio.h>
#include<stdlib.h>
#pragma pack(1)
/*
struct date
{
	int dd, mm, yy;
};
struct emp
{
	int empno;
	char name[10];
	float sal;
	struct date doj;
};
*/

struct emp
{
	int empno;
	char name[10];
	float sal;
	struct date
	{
		int dd, mm, yy;
	}doj;
};


void AcceptEmpInfo(struct emp *e); // size of e= 4 or 8 bytes
//void PrintEmpInfo(struct emp e);// size of e=18 bytes
void PrintEmpInfo(const struct emp *e);// size of e=4 or 8 bytes
int main(void)
{
	struct emp e1;
	// struct emp is user defined data type
	// e1 is variable (object) of user defined data type struct emp

	printf("\n Enter Employee info :: ");
	AcceptEmpInfo(&e1); // e1 is actual argument

	printf("\n Employee info :: in main \n");
 	//PrintEmpInfo(e1);// e1 is actual argument
	PrintEmpInfo(&e1);// e1 is actual argument

	return 0;
}
// e is formal argument
void AcceptEmpInfo(struct emp *e)
{
	printf("\n Enter Emp no:: ");
	scanf("%d", &e->empno);

	printf("\n Enter Emp name:: ");
	scanf("%s", e->name);

	printf("\n Enter Emp sal:: ");
	scanf("%f", &e->sal);

	printf("\n Enter doj in dd-mm-yyyy format ::");
	scanf("%d%*c%d%*c%d", &e->doj.dd, &e->doj.mm, &e->doj.yy);
	//%*c use to avoide - or / or .
	return;
}
//e is formal argument
void PrintEmpInfo(const struct emp *e)
{
	//e->sal=0; as e is const
	printf("\n EmpNo     name   sal   doj \n");
	printf("\n %-6d %-10s %6.2f  %d-%d-%d", e->empno, e->name, e->sal, e->doj.dd, e->doj.mm, e->doj.yy);

	return;
}


