#include<stdio.h>
#include<stdlib.h>
int main(void)
{
	int *ptr=NULL, no, index;

	printf("\n Enter how many elements you want :: ");
	scanf("%d", &no);

	ptr= (int*)malloc(sizeof(int)*no);
	if(ptr==NULL)
		printf("\n unable to allocate memory ");
	else
	{
		printf("\n Enter array element :: \n");
		for(index=0; index<no; ++index)
		{
			printf("\n (ptr+%d) ::", index);
			//scanf("%d", (ptr+index)); //pointer notation
			//scanf("%d", (index+ptr));
			//scanf("%d", &ptr[index]); // array notation
			scanf("%d", &index[ptr]);
		}
		printf("\n elements of array :: \n ");
		printf("\n &ptr=%u ptr=%u ", &ptr, ptr);
		for(index=0; index<no; ++index)
		{
			//printf("\n (ptr+%d) *(ptr+index)%d [%u]", index, *(ptr+index), (ptr+index));
			//printf("\n (%d+ptr) *(index+ptr)%d [%u]", index, *(index+ptr), (index+ptr));
			//printf("\n ptr[%d] ptr[%d]\t%d \t[%u]", index,index, ptr[index], &ptr[index]);
			printf("\n [%d]ptr [%d]ptr\t%d \t[%u]", index,index, index[ptr], &index[ptr]);
		}
		free(ptr);
		ptr=NULL;
		printf("\n memory is freed");

	}

	return 0;
}

// on terminal
// gcc demo4.c   --->> a.out
// ./a.out  -->> to run
// to check memory leakage
//valgrind ./a.out


