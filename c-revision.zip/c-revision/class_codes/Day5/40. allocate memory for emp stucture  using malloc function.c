#include<stdio.h>
#include<stdlib.h>
#pragma pack(1)
struct emp
{
	int empno;
	char name[10];
	float sal;
};
int main(void)
{
	struct emp *ptr=NULL;

	ptr= (struct emp*)malloc(sizeof(struct emp)*1);

	printf("\n Enter Emp no:: ");
	scanf("%d", &ptr->empno);

	printf("\n Enter Emp name:: ");
	scanf("%s", ptr->name);

	printf("\n Enter Emp sal:: ");
	scanf("%f", &ptr->sal);

	printf("\n EmpNo     name   sal using -> operator\n");
	printf("\n %-6d %-10s %6.2f", ptr->empno, ptr->name, ptr->sal);

	printf("\n EmpNo     name   sal using . operator\n");
	printf("\n %-6d %-10s %6.2f", (*ptr).empno, (*ptr).name, (*ptr).sal);

	free(ptr);
	ptr=NULL;
	printf("\n Memory is freed");
	return 0;
}


