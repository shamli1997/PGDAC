#include<stdio.h>
#include<stdlib.h>
#define SIZE 3
#pragma pack(1)
//way 1 nested struture
/*
struct date
{
	int dd, mm, yy;
};
struct emp
{
	int empno;
	char name[10];
	float sal;
	struct date doj;
};
*/
// way 2 nested struct
struct emp
{
	int empno;
	char name[10];
	float sal;
	struct date
	{
		int dd, mm, yy;
	}doj;
};



void AcceptEmpInfo(struct emp e[], int size);
void PrintEmpInfo(const struct emp e[],int size);
int main(void)
{
	struct emp e1[SIZE];

	printf("\n Enter Employee info :: ");
	AcceptEmpInfo(e1,SIZE);

	printf("\n Employee info :: in main \n");
	PrintEmpInfo(e1,SIZE);

	return 0;
}
// e is formal argument
void AcceptEmpInfo(struct emp e[],int size)
{
	int i;

	for(i=0; i<size;i++)
	{
		printf("\n Enter Emp no:: ");
		scanf("%d", &e[i].empno);

		printf("\n Enter Emp name:: ");
		scanf("%s", e[i].name);

		printf("\n Enter Emp sal:: ");
		scanf("%f", &e[i].sal);

		printf("\n Enter doj in dd-mm-yyyy format ::");
		scanf("%d%*c%d%*c%d", &e[i].doj.dd, &e[i].doj.mm, &e[i].doj.yy);
		//%*c use to avoide - or / or .
	}

	return;
}
void PrintEmpInfo(const struct emp e[],int size)
{
	int i;
	printf("\n EmpNo     name   sal   doj \n");
	for(i=0; i<size; i++)
	{
		printf("\n %-6d %-10s %6.2f  %d-%d-%d\n", e[i].empno, e[i].name, e[i].sal, e[i].doj.dd, e[i].doj.mm, e[i].doj.yy);
	}

	return;
}


